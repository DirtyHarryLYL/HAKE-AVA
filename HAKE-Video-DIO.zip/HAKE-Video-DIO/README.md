# HAKE-DIO
HAKE-DIO contains the bounding box (TODO) and object class (TODO) annotations of all the interacive objects in AVA videos (v2.2), according to the labeled humans in AVA v2.2 performing Human-Object Interactions (HOI, TODO classes). 
